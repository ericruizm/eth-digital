import React from 'react'
import '../inicio/Inicio.css'
import './Portfolio.css'

const EncabezadoPortfolio2 = () => {
  return (
    <div>
      <div className="EncabezadoPorfolio2">
        <div className="Grid_EncabezadoPorfolio2">
          <h2>Servicios </h2>
          <h3>EAGLE GROUP</h3>
        </div>
      </div>
    </div>
  )
}

export default EncabezadoPortfolio2
