import React from 'react';
import Aportaciones from './Aportaciones';

const Movimientos = (props) => (
  <div>
    <Aportaciones />
  </div>
);

export default Movimientos;
